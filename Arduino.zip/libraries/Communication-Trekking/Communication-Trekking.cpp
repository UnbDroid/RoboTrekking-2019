#include "Arduino.h"
#include "Communication-Trekking.h"

static byte motor, count, pwm, read_char;

static unsigned long time;
static unsigned long ref_time;

void setup_communication(){
	Serial.begin(115200);

    pinMode(MOTOR_L_A, OUTPUT);
    pinMode(MOTOR_L_B, OUTPUT);
    pinMode(MOTOR_R_A, OUTPUT);
    pinMode(MOTOR_R_B, OUTPUT);
    digitalWrite(MOTOR_L_A, LOW);
    digitalWrite(MOTOR_L_B, HIGH);
    digitalWrite(MOTOR_R_A, LOW);
    digitalWrite(MOTOR_R_B, HIGH);

    count = 0;
    pwm = 0;

    time = millis();
    ref_time = time;
}

void communication(int * flag){
    

 	if(Serial.available()){
        read_char = Serial.read();

        if(*flag == 0 ) {
            ref_time = millis();
            *flag = 1;
        }
        if(*flag == 1 && ((time - ref_time) > 40*1e3)){
            *flag = 2;
        }

        if(count){
            if(read_char > '9' || read_char < '0'){
                count = 0;
                pwm = 0;
            }
            else {
                pwm = pwm + count*(read_char - '0');
                count = count/10;

                if(!count){
                    if(motor == 'd'){
                        analogWrite(MOTOR_R_PWM, pwm);
                    }
                    else if(motor == 'e'){
                        analogWrite(MOTOR_L_PWM, pwm);
                    }
                    pwm = 0;
                }
            }
        }

        // Not inside an 'else' for resetting count even if lost some bytes 
        if(read_char == 'd' || read_char == 'e'){
            motor = read_char;
            count = 100;
        }
   
        time = millis();
    }
    else if( (millis()-time) > 3*1e3 ){
        // 3 seconds not receiving anything, turn off motors
        
        analogWrite(MOTOR_R_PWM, 0);
        analogWrite(MOTOR_L_PWM, 0);

        time = millis();
        *flag = 0;
    }   

}