#ifndef COMM_TREKKING
#define COMM_TREKKING

// Motor constants

#define MOTOR_L_A 8
#define MOTOR_L_B 7
#define MOTOR_L_PWM 6

#define MOTOR_R_A 11
#define MOTOR_R_B 10
#define MOTOR_R_PWM 9

void setup_communication();

void communication(int *);

#endif