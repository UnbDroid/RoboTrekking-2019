#include "Arduino.h"
#include "Light-Trekking.h"
 
static unsigned long start_time = 0;

void setup_light_sign() {                                                                                                                               
    pinMode(LIGHT_SIGN, OUTPUT);
}

void light_on(){
    digitalWrite(LIGHT_SIGN, HIGH); 
    start_time = millis();    
}

void light_off(){
    digitalWrite(LIGHT_SIGN, LOW);   
}

void get_sign(byte us_byte) {
    if((millis()-start_time) >= 2000) light_off();

    if(us_byte != 0) light_on();
}