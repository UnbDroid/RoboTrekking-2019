#ifndef LIGHT-TREKKING
#define LIGHT-TREKKING

#define LIGHT_SIGN 2

void light_on(); 

void light_off(); 

void setup_light_sign();

// check if there is something close
void get_sign(byte us_byte); 

#endif