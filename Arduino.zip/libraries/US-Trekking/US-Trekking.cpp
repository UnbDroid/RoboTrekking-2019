#include "Arduino.h"
#include "US-Trekking.h"

uint8_t us_byte;

NewPing sonar[SONAR_NUM] = {   
    NewPing(US1_TRIG, US1_ECHO, MAX_DISTANCE), 
    NewPing(US2_TRIG, US2_ECHO, MAX_DISTANCE), 
    NewPing(US3_TRIG, US3_ECHO, MAX_DISTANCE),
    NewPing(US4_TRIG, US4_ECHO, MAX_DISTANCE)
};

#ifdef ALFA
float low_pass_filter(float last_val, float new_val)
{
  return ((ALFA)*last_val + (1.0-ALFA)*new_val);
}
#endif

void setup_us() {
  us_byte = 0x00;
}


#ifdef ALFA
uint8_t value_per_us(float value)
#else
uint8_t value_per_us(unsigned long value)
#endif
{
    if ( (value > 5.0) && (value < 40.0) )
        return 0x01;
    return 0x0;
}

#ifdef ALFA
uint8_t mask(float* filtered_us)
#else
uint8_t mask(unsigned long* readings_us)
#endif
{
    uint8_t aux = 0x00;
    us_byte = 0x00;
    for (int8_t i = SONAR_NUM-1; i >= 0 ; i--)
    {
        #ifdef ALFA
        aux = value_per_us(filtered_us[i]);
        #else
        aux = value_per_us(readings_us[i]);
        #endif
        us_byte |= aux;
        if(i!=0)
            us_byte = us_byte << 0x01;
    }
  
}

byte read_us() 
{
    uint8_t i, j;
    #ifdef ALFA
        static float filtered_us[SONAR_NUM];
        for(i=0;i<SONAR_NUM;i++){
            filtered_us[i] = 0.0;
        }
    #else
        unsigned long readings_us[SONAR_NUM]; 
        for(i=0;i<SONAR_NUM;i++){
            readings_us[i] = 0.0;
        }   
    #endif
    
    #ifdef ALFA
    for (j = 0; j < (uint8_t)(1/(1-ALFA))+1; j++)
    {
    #endif
        
        for (i = 0; i < SONAR_NUM; i++) { // Loop through each sensor and display results.
        #ifdef ALFA
            filtered_us[i] = low_pass_filter(filtered_us[i],sonar[i].ping_cm());
        #else
            readings_us[i] = sonar[i].ping_cm();
        #endif

            delay(28);
        }
    
    #ifdef ALFA
    }
    #endif

    #ifdef ALFA
        mask(filtered_us);
    #else
        mask(readings_us);
    #endif

    return us_byte;
}