#ifndef US_TREKKING
#define US_TREKKING

#include <NewPing.h>

#define SONAR_NUM 4
#define MAX_DISTANCE 200 // Maximum distance (in cm) to ping.

//#define ALFA 0.8

#define US1_ECHO A4
#define US1_TRIG A5
#define US2_ECHO A2
#define US2_TRIG A3
#define US3_ECHO A0
#define US3_TRIG A1
#define US4_ECHO 12
#define US4_TRIG 13

#ifdef ALFA
float low_pass_filter(float last_val, float new_val);
#endif

void setup_us();

//READ THE LINES BELOW !!!!!!!!!!!!

//the ALFA define activates and deactivates the low_pass_filter, if you need faster results and dont want to wait for the results to get stable you can delete the line defining it

//____________________________________________
//bits representation of ULTRASSONICS:

// | US3 | US2 | US1 | US0 |
// |b8 b7|b6 b5|b4 b3|b2 b1|

// 00 between 0 and 50 cms
// 01 between 50 and 100 cms
// 10 between 100 and 150 cms
// 11 between 150 and 200 cms or more 

#ifdef ALFA
uint8_t value_per_us(float value);
#else
uint8_t value_per_us(unsigned long value);
#endif


#ifdef ALFA
uint8_t mask(float* filtered_us);
#else
uint8_t mask(unsigned long* readings_us);
#endif

//___________******************************************_________________________
// it is necessary to read the sensor at least CEIL(1/1-ALFA) for a stable result ... example (4 sensors will need 5 readings each)
//5x4 readings = 20 and each reading with the delay is about 50ms, reading all of them with filter and waiting for the stabilization will take about 1 second.
// if you disable the filter youll need only one rreading and then 4 x 50ms = 200ms

byte read_us(); //WARNING: TO GUARANTEE BEST RESULTS,  29ms should be the shortest delay between pings (keep the delay inside the loop)

#endif